<?php

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../models/Usuarios.php';
require_once __DIR__ . '/../utils/Security.php';
require_once __DIR__ . '/../utils/Session.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_GET['action'] ?? '';

    if ($action === 'postarVaga') {
        handlePostarVaga($pdo);
    } else if ($action === 'buscarVaga') {
        handleBuscarVaga($pdo);
    }
}

function getRequestData()
{
    return $_POST;
}

function handlePostarVaga($pdo)
{
    Session::start();

    $dados = getRequestData();

    $userEmpresa = new Usuario($pdo);

    $id_empresa =  $userEmpresa->findByIdEmpresa($_SESSION['user_id']);

    try {
        $userModel = new Usuario($pdo);

        // Transação segura (banco empresa e pessoa)
        $pdo->beginTransaction();

        $dados = [
            'titulo' => Security::sanitizeInput($dados['titulo'] ?? ''),
            'descricao' => Security::sanitizeInput($dados['descricao'] ?? ''),
            'tipo' => $dados['tipo'] ?? '',
            'salario' => (float) ($dados['salario'] ?? 0),
            'cidade' => Security::sanitizeInput($dados['cidade'] ?? ''),
            'status' => $dados['status'] ?? ''
        ];

        if (empty($dados['titulo'])) {
            throw new Exception("Título é obrigatório");
        }

        $userModel->createVaga($id_empresa, $dados);

        // Se der tudo certo, confirma tudo
        $pdo->commit();

        // Sucesso
        $_SESSION['sucesso'] = "✅ Vaga criada com sucesso!";
        header("Location: ../../../public/views/dashboardEmpresa.php");
        exit();
    } catch (PDOException $e) {
        echo $e->getMessage();
        exit();
        error_log("Erro ao criar vaga " . $e->getMessage());

        // Se estiver em transaction, o rollBack volta se der alguma coisa errada
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }

        $_SESSION['cadastro_errors'] = ["⚠️ Erro no sistema. Tente novamente mais tarde."];
        header("Location: ../../../public/views/testePostarVaga.php"); // <-- MANDAR PARA O FORMULÁRIO DE VAGA NOVAMENTE
        exit();
    }
}


function handleBuscarVaga($pdo)
{

    $errors = [];

    try {

        $userModel = new Usuario($pdo);

        $vagas = $userModel->buscarVaga();
    } catch (PDOException $e) {
        error_log("Erro ao trazer vagas: " . $e->getMessage());
        $errors[] = "Erro no sistema. Volte mais tarde.";
    }


    if (!empty($errors)) {
        header("Location: "); //<-- VOLTAR PAAR A TELA DE VAGAS
        exit();
    }

    return $vagas;
}
